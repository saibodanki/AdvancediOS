//
//  networkCallingViewController.swift
//  contacts
//
//  Created by SAI KRISHNA KUMAR BODANKI on 12/07/19.
//  Copyright © 2019 SAI KRISHNA KUMAR BODANKI. All rights reserved.
//

import UIKit
import Alamofire


class networking {
    typealias webResponse = ([[String:Any]]? , Error?) -> Void
    
    
   
  
    func executeGet(_ url: URL , completion: @escaping webResponse ) {
        Alamofire.request(url, method: .get).responseJSON { response in
            
            if let error = response.error {
                completion(nil, error)
            } else if let jsonArray = response.result.value as? [[String:Any]] {
                completion(jsonArray , nil)
            } else if let jsonDict = response.result.value as? [String:Any] {
                completion([jsonDict] , nil)
                
            }
            
        }
        
    }
    
    
    
}

