//
//  contactCustomCellTableViewCell.swift
//  contacts
//
//  Created by SAI KRISHNA KUMAR BODANKI on 07/07/19.
//  Copyright © 2019 SAI KRISHNA KUMAR BODANKI. All rights reserved.
//

import UIKit

class contactCustomCellTableViewCell: UITableViewCell {

    
    
    @IBOutlet weak var mainImgView: UIImageView!
    
    @IBOutlet weak var nameLbl: UILabel!
    
    @IBOutlet weak var emailLbl: UILabel!
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        imageCrop()
        // Initialization code
    }
    
    func imageCrop() {
        mainImgView.layer.borderWidth=1.0
        mainImgView.layer.masksToBounds = false
        mainImgView.layer.borderColor = UIColor.white.cgColor
        mainImgView.layer.cornerRadius = mainImgView.frame.size.height/2
        mainImgView.clipsToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
